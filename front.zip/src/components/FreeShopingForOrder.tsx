
import React from "react";

const FreeShopingForOrder =()=>{
    return(
        <div className="header__top__left">
            <ul>
                <li><i className="fa fa-envelope"></i> <a href="/cdn-cgi/l/email-protection"
                                                          className="__cf_email__">[email&#160;protected]</a>
                </li>
                <li>Free Shipping for all Order of $99</li>
            </ul>
        </div>
    )
}

export default FreeShopingForOrder
