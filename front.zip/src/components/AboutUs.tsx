import React from "react";
import Wrapper from "./Wrapper";


const AboutUs = () =>{
    return(
        <Wrapper>
            <div className={"aboutUs"}>
                this project was written by Tigran Hakobian in 2021, that was a second task for Tigran and this is a About us Component )
            </div>
        </Wrapper>
    )
}
export default AboutUs

