import React from "react";

const Langs = () =>{
    return(
        <div className="header__top__right__language">
            <div>English</div>

            <ul>
                <li><span>Spanis</span></li>
                <li><span>English</span></li>
            </ul>
        </div>
    )
}

export default Langs
