import React from "react";

const LoginInHeader = () =>{
    return(
        <div className="header__top__right__auth">
            <span ><i className="fa fa-user"/> Login</span>
        </div>
    )
}

export default LoginInHeader
