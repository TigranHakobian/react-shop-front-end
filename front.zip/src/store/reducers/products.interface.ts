export type StateType = {
    prodData: Array<any> | null
}
